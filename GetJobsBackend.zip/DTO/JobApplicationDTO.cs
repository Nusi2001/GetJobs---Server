namespace GetJobsBackend.DTO
{
    public class JobApplicationDTO
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public int JobId { get; set; }
    }
}
